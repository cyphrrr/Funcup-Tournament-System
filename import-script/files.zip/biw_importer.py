#!/usr/bin/env python3
"""
BIW Pokal API Importer
Importiert gescrapte Daten in das FastAPI Backend
"""

import requests
import json
import logging
from pathlib import Path
from typing import Dict, List, Optional
from datetime import datetime
import time

# Setup Logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('biw_import.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


class BIWImporter:
    """Import scraped BIW data to FastAPI backend"""
    
    def __init__(self, base_url: str = "http://localhost:8000"):
        self.base_url = base_url.rstrip('/')
        self.session = requests.Session()
        self.stats = {
            'seasons_created': 0,
            'groups_created': 0,
            'teams_created': 0,
            'matches_created': 0,
            'errors': []
        }
        
    def load_data(self, filepath: str) -> Dict:
        """Load scraped JSON data"""
        logger.info(f"Loading data from {filepath}")
        with open(filepath, 'r', encoding='utf-8') as f:
            return json.load(f)
    
    def create_season(self, season_number: int) -> Optional[int]:
        """Create a season and return its ID"""
        url = f"{self.base_url}/api/seasons"
        
        payload = {
            "name": f"Saison {season_number}",
            "participant_count": 0,  # Will be updated later
            "status": "archived" if season_number < 50 else "active"
        }
        
        try:
            response = self.session.post(url, json=payload, timeout=10)
            response.raise_for_status()
            season_data = response.json()
            season_id = season_data['id']
            
            logger.info(f"✓ Created Season {season_number} (ID: {season_id})")
            self.stats['seasons_created'] += 1
            return season_id
            
        except requests.RequestException as e:
            error = f"Failed to create Season {season_number}: {str(e)}"
            logger.error(error)
            self.stats['errors'].append(error)
            return None
    
    def create_group(self, season_id: int, group_name: str, sort_order: int) -> Optional[int]:
        """Create a group and return its ID"""
        url = f"{self.base_url}/api/seasons/{season_id}/groups"
        
        payload = {
            "name": group_name,
            "sort_order": sort_order
        }
        
        try:
            response = self.session.post(url, json=payload, timeout=10)
            response.raise_for_status()
            group_data = response.json()
            group_id = group_data['id']
            
            logger.info(f"  ✓ Created Group {group_name} (ID: {group_id})")
            self.stats['groups_created'] += 1
            return group_id
            
        except requests.RequestException as e:
            error = f"Failed to create Group {group_name}: {str(e)}"
            logger.error(error)
            self.stats['errors'].append(error)
            return None
    
    def create_or_get_team(self, team_name: str) -> Optional[int]:
        """Create team if doesn't exist, return team ID"""
        # First, try to find existing team
        url = f"{self.base_url}/api/teams"
        
        try:
            # Search for existing team
            response = self.session.get(url, params={'name': team_name}, timeout=10)
            response.raise_for_status()
            teams = response.json()
            
            if teams and len(teams) > 0:
                # Team exists
                team_id = teams[0]['id']
                logger.debug(f"    Team '{team_name}' exists (ID: {team_id})")
                return team_id
            
            # Team doesn't exist, create it
            payload = {
                "name": team_name,
                "logo_url": None,
                "onlineliga_url": None
            }
            
            response = self.session.post(url, json=payload, timeout=10)
            response.raise_for_status()
            team_data = response.json()
            team_id = team_data['id']
            
            logger.info(f"    ✓ Created Team '{team_name}' (ID: {team_id})")
            self.stats['teams_created'] += 1
            return team_id
            
        except requests.RequestException as e:
            error = f"Failed to create/get Team '{team_name}': {str(e)}"
            logger.error(error)
            self.stats['errors'].append(error)
            return None
    
    def assign_team_to_season(self, season_id: int, team_id: int, group_id: int) -> bool:
        """Assign team to season and group"""
        url = f"{self.base_url}/api/seasons/{season_id}/teams"
        
        payload = {
            "team_id": team_id,
            "group_id": group_id
        }
        
        try:
            response = self.session.post(url, json=payload, timeout=10)
            response.raise_for_status()
            return True
            
        except requests.RequestException as e:
            # Might already exist, that's OK
            if "already assigned" in str(e).lower() or "409" in str(e):
                logger.debug(f"    Team {team_id} already assigned to season {season_id}")
                return True
            
            error = f"Failed to assign Team {team_id} to Season {season_id}: {str(e)}"
            logger.warning(error)
            return False
    
    def create_match(self, season_id: int, group_id: int, match_data: Dict) -> bool:
        """Create a match"""
        url = f"{self.base_url}/api/seasons/{season_id}/matches"
        
        # Get team IDs
        home_team_id = self.create_or_get_team(match_data['home_team'])
        away_team_id = self.create_or_get_team(match_data['away_team'])
        
        if not home_team_id or not away_team_id:
            logger.error(f"    Failed to get team IDs for match")
            return False
        
        # Assign teams to season/group
        self.assign_team_to_season(season_id, home_team_id, group_id)
        self.assign_team_to_season(season_id, away_team_id, group_id)
        
        payload = {
            "season_id": season_id,
            "group_id": group_id,
            "home_team_id": home_team_id,
            "away_team_id": away_team_id,
            "home_goals": match_data['home_goals'],
            "away_goals": match_data['away_goals'],
            "status": match_data['status'],
            "matchday": match_data['matchday'],
            "ingame_week": match_data.get('matchday', 1)  # Use matchday as ingame_week fallback
        }
        
        try:
            response = self.session.post(url, json=payload, timeout=10)
            response.raise_for_status()
            self.stats['matches_created'] += 1
            return True
            
        except requests.RequestException as e:
            error = f"Failed to create match {match_data['home_team']} vs {match_data['away_team']}: {str(e)}"
            logger.error(error)
            self.stats['errors'].append(error)
            return False
    
    def import_season(self, season_data: Dict) -> bool:
        """Import complete season with all groups and matches"""
        season_number = season_data['season']
        logger.info(f"========== IMPORTING SEASON {season_number} ==========")
        
        # Create season
        season_id = self.create_season(season_number)
        if not season_id:
            return False
        
        # Import each group
        for idx, group_data in enumerate(season_data['groups']):
            group_name = group_data['group']
            logger.info(f"  Importing Group {group_name}...")
            
            # Create group
            group_id = self.create_group(season_id, group_name, idx + 1)
            if not group_id:
                continue
            
            # Import matches
            matches = group_data['matches']
            logger.info(f"    Importing {len(matches)} matches...")
            
            success_count = 0
            for match in matches:
                if self.create_match(season_id, group_id, match):
                    success_count += 1
                time.sleep(0.1)  # Rate limiting
            
            logger.info(f"    ✓ Imported {success_count}/{len(matches)} matches")
        
        return True
    
    def import_all(self, data: Dict, skip_existing: bool = True):
        """Import all data"""
        logger.info("=" * 60)
        logger.info("STARTING IMPORT TO API")
        logger.info(f"API Base URL: {self.base_url}")
        logger.info("=" * 60)
        
        # Test API connection
        try:
            response = self.session.get(f"{self.base_url}/api/health", timeout=5)
            response.raise_for_status()
            logger.info("✓ API connection successful")
        except Exception as e:
            logger.error(f"✗ Cannot connect to API: {str(e)}")
            return
        
        # Import each season
        for season_data in data['seasons']:
            try:
                self.import_season(season_data)
                time.sleep(1)  # Pause between seasons
                
            except Exception as e:
                error = f"Failed to import Season {season_data['season']}: {str(e)}"
                logger.error(error, exc_info=True)
                self.stats['errors'].append(error)
                
                # Ask if we should continue
                if not self.should_continue():
                    logger.warning("Import aborted by user")
                    break
    
    def should_continue(self) -> bool:
        """Ask user if import should continue after error"""
        # For automated use, always continue
        # For interactive use, you could add input() here
        return True
    
    def print_summary(self):
        """Print import summary"""
        logger.info("")
        logger.info("=" * 60)
        logger.info("IMPORT SUMMARY")
        logger.info("=" * 60)
        logger.info(f"Seasons created: {self.stats['seasons_created']}")
        logger.info(f"Groups created: {self.stats['groups_created']}")
        logger.info(f"Teams created: {self.stats['teams_created']}")
        logger.info(f"Matches created: {self.stats['matches_created']}")
        logger.info(f"Errors: {len(self.stats['errors'])}")
        
        if self.stats['errors']:
            logger.warning("")
            logger.warning("ERRORS:")
            for error in self.stats['errors'][:10]:  # Show first 10
                logger.warning(f"  - {error}")
            if len(self.stats['errors']) > 10:
                logger.warning(f"  ... and {len(self.stats['errors']) - 10} more")
        
        logger.info("=" * 60)


def main():
    """Main execution"""
    import argparse
    
    parser = argparse.ArgumentParser(description='Import BIW data to API')
    parser.add_argument('data_file', help='Path to scraped JSON data file')
    parser.add_argument('--api-url', default='http://localhost:8000',
                       help='API base URL (default: http://localhost:8000)')
    parser.add_argument('--skip-existing', action='store_true',
                       help='Skip seasons that already exist')
    
    args = parser.parse_args()
    
    # Verify file exists
    data_path = Path(args.data_file)
    if not data_path.exists():
        logger.error(f"Data file not found: {args.data_file}")
        return
    
    # Create importer and run
    importer = BIWImporter(base_url=args.api_url)
    
    try:
        data = importer.load_data(args.data_file)
        importer.import_all(data, skip_existing=args.skip_existing)
        importer.print_summary()
        
    except KeyboardInterrupt:
        logger.warning("Import interrupted by user")
        importer.print_summary()
    except Exception as e:
        logger.error(f"Fatal error: {str(e)}", exc_info=True)


if __name__ == "__main__":
    main()
